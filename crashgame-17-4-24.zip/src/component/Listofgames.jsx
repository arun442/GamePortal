import React, { useState,useEffect} from 'react';
import './Listofgames.css'
import wallet from '../wallet.png'
import crashlogo from '../crashlogo.jpg';
import { useNavigate ,useLocation} from "react-router-dom";


const Listofgames=()=>{
    const navigate = useNavigate();

    const [balance,setbalance]=useState(1000);

   

const opengame=()=>{
    navigate('/crashgame')
}
    return(
        <div className='container1'>
            <div className='row' style={{backgroundColor:'#0a152f',height:'15vh',display:'flex',justifyContent:'center',alignItems:'center',color:'white'}}>
<div className='col-md-6' style={{textAlign:'start',padding:'20px'}}>
    ARUN
</div>
<div className='col-md-6' style={{display:'flex',justifyContent:'end',padding:'30px'}}>
<img src={wallet} style={{height:'50px'}}/><h2>{balance}</h2>
        </div>
            </div>
            <div className='row'>
            <div class="card" style={{width:"18rem"}}>
  <img src={crashlogo} class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">Crash Game</h5>
    <button className='btn1' onClick={opengame}>PLAY</button>
  </div>
</div>
            </div>
        </div>
    )
}
export default Listofgames;