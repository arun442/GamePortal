import React, { useState,useEffect} from 'react';
import rocket from '../rocket.png'
import './CrashGame.css'
import blast from '../blast.gif'
import spacebackground from '../spacebackground.jpg'
import money from '../money.png';
import wallet from '../wallet.png'
import rocketready from '../rocket3.png'
import { useNavigate ,useLocation} from "react-router-dom";
import logout from '../exit.png';
import rupee from '../rupee.png'
import coins from '../coin.png'

import { CountUp } from 'use-count-up'
import { useCountUp } from 'react-countup';
const CrashGame = () => {
let ranval=(Math.random()*0)+1
let doublevalue=1;
// var randomnum=(Math.random()*ranval)+1
    const [randomnum,setrandomnum]=useState((Math.random()*ranval)+1);
    const [showrocket,setshowrocket]=useState(true);
    const [showblast,setshowblast]=useState(false);
    const [balance,setbalance]=useState(1000);
    const [bettingamt,setbettingamt]=useState(0);
    const [inputbox,setinputbox]=useState(0);
    const [showcashout,setcashout]=useState(false);
    const [showplaybtn,setshowplaybtn]=useState(false);
    const [btnname,setbtnname]=useState('PLAY');
    const [countdownpage,setcountdownpage]=useState(true);
    const [blasted,setblasted]=useState(false);
    const [message,setmessage]=useState('');
    const [amounttake,setamounttake]=useState(false);
    const [isTabActive, setIsTabActive] = useState(true);
    const [gettingx,setgettingx]=useState(1);

    const location = useLocation();
    
    const navigate = useNavigate();
   
    window.location.hash = "no-back-button";


    window.onhashchange = function(){
        window.location.hash = "no-back-button";
    }
    useEffect(()=>{
        setamounttake(false)
        setblasted(false);
        setTimeout(() => {     


            setshowplaybtn(true);
            console.log('useeff random',randomnum);
            setshowrocket(false)
        setcountdownpage(false)
        
        console.log(location.pathname);
        document.getElementById('rocketblast').style.animation='blast 5s'

        setTimeout(() => {
            setcashout(false)
            setblasted(true);
            setshowblast(true);
setTimeout(() => {
    setshowrocket(true)
    setshowblast(false);
    document.getElementById('scrollimg').style.animationPlayState='paused';
    document.getElementById('rocketblast').style.animation='none';
    setblasted(false);
    setbtnname("PLAY")
    console.log(countdownpage);
    setTimeout(() => {
        setcountdownpage(true);
        setshowplaybtn(false);
        document.getElementById('resulttext').style.display='none'
    }, 3000);
        document.getElementById('resulttext2').style.display='none'
        
// setrandomnum((Math.random()*ranval)+1)
    // xvalue();
}, 500);
        },(randomnum*3)*1000);

        
    }, 7000);
    const handleVisibilityChange = () => {
        setIsTabActive(!document.hidden);
      };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Cleanup function to remove event listener
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
    },[])

    let coutner = () =>{
        
    }
    useEffect(()=>{
        console.log(blasted,amounttake,btnname);

        if (btnname=="ACCEPTED"&&!amounttake&&blasted) {
            console.log('blast',amounttake);
                document.getElementById('resulttext2').style.display='inline'
            
        }
        if (btnname=="ACCEPTED"&&amounttake&&blasted) {
            console.log('blast',amounttake);
                document.getElementById('resulttext').style.display='inline'
            
        }
    },[btnname,amounttake,blasted])
    useEffect(() => {
        console.log('tabactive',isTabActive);
        if (!isTabActive) {
          window.location.reload();
        }
      }, [isTabActive]);


   const xvalue=()=>{
    console.log('xvaluecaled');
setblasted(false);
setamounttake(false)
// if (bettingamt>1) {
//     setcashout(false)
// }
    setTimeout(() => {
        console.log('xvaluefun',randomnum);
setcountdownpage(false);
        setshowplaybtn(true);
        ranval=(Math.random()*3)+1
        const randomvariable=(Math.random()*ranval)+1
        setrandomnum(randomvariable)
        console.log(randomvariable);
    document.getElementById('scrollimg').style.animationPlayState='initial';
    document.getElementById('rocketblast').style.animation='blast 5s'
        

    setshowrocket(false)
    setTimeout(() => {
        setcashout(false)
        setblasted(true);
        setshowblast(true)
setTimeout(() => {
setshowrocket(true)
setshowblast(false);
setblasted(false);
document.getElementById('scrollimg').style.animationPlayState='paused';
document.getElementById('rocketblast').style.animation='none';

setbtnname("PLAY")
setTimeout(() => {
    setcountdownpage(true);
    setshowplaybtn(false);
    document.getElementById('resulttext').style.display='none'

}, 3000);
    document.getElementById('resulttext2').style.display='none'
    
console.log(amounttake);


}, 500);
    },(randomvariable*3)*1000);
    }, 8000);

  
    return { shouldRepeat: true,delay:8}

   }
   const setbetamount=(e)=>{
    setinputbox(Math.abs(e.target.value));
console.log(e);

       }
   const amountadd=()=>{
    console.log(balance);
    console.log(inputbox);
    if (balance>=inputbox&&inputbox>=1) {
        setbtnname("ACCEPTED");
        const calcbalance=(balance-inputbox).toFixed(2)
        console.log(Number(calcbalance));
        setbalance(Number(calcbalance) )
        console.log(inputbox);
        setbettingamt(inputbox)
        setcashout(true)
setinputbox(0);
document.getElementById('amtbox').value="";


// debugger;

    }
// setbettingamt(inputbox);
   }
   const checkblast=()=>{
    if (blasted) {

    }else{
        setamounttake(true)
        setgettingx(doublevalue);
        console.log(doublevalue);
        console.log(Number(bettingamt) +" "+Number(doublevalue)+"="+Number(bettingamt)*Number(doublevalue));
        const calcbalance=Number(bettingamt)*Number(doublevalue);
        console.log('total',Number((Number(balance)+Number(calcbalance)).toFixed(2)));
        setbalance(Number((Number(balance)+Number(calcbalance)).toFixed(2)))
        setcashout(false)
    }
   }
   const goback=()=>{
    console.log('clicked');
    navigate('/allgames')
    window.location.reload()
   }
   
  return (
    <div className='container'>
        {/* <h1 style={{color:'white',background:message=="win"?'red':"green"}}>{message}</h1> */}
        <div class="scrolling-image-container">
 <div class="scrolling-image" id='scrollimg'></div>
 {!countdownpage?<h1 style={{position:'fixed',width:'fit-content',top:'20%',left:'10%',color:'white'}} >
        <CountUp isCounting start={1} end={randomnum} duration={randomnum*3} decimalPlaces={2} decimalSeparator='.' easing={'easeInCubic'} onComplete={xvalue} onUpdate={(currentvalue)=>{doublevalue=currentvalue}}  id="count"/> x
        </h1>:null}
        
       {btnname==="ACCEPTED"?
       <div style={{position:'fixed',width:'fit-content',top:'30%',left:'10%',color:'#09f309',display:'flex'}}><h2>Bet Amount:₹{bettingamt}</h2>&nbsp;&nbsp;{amounttake?<h2>x&nbsp;{gettingx}</h2>:null}
       </div>:null}
        <div className='showwallet'>
<img src={wallet} style={{height:'50px'}}/><h2>{balance}</h2>
        </div>
       {btnname=="PLAY"?<img src={logout} style={{height:'50px',position:'fixed',top:'20%',right:'5%',cursor:'pointer'}} onClick={goback}/>:null}

       {showcashout&&!countdownpage? <button class="button" onClick={checkblast}>
  CASH OUT<img src={money} style={{height:'100%'}}/>
</button>:null}
       
</div>

       
         {/* <marquee behavior="scroll" direction="down">
            <img src={spacebackground} style={{height:'100vh',width:'100vw'}}/>
         </marquee> */}
     <div className='rocketblast' id='rocketblast'>
     {!showrocket?<img  className='rocket' src={rocket}/>:null}
     {showblast?<iframe className='explosion' src={blast} ></iframe>:null}
       
</div>
{countdownpage?<div style={{position:'fixed',top:'50%',left:'35%',height:'200px'}} >
    <img src={rocketready} style={{height:'150px'}} className='readytogo'/>
    <h2 className='texts'>Next Round Starts in <CountUp isCounting start={8} end={0} duration={5}  easing={'linear'}  /> </h2>
</div>:null}
{!countdownpage?<div style={{position:'fixed',top:'50%',left:'35%'}} >
   
</div>:null}
<div className='playbtn row'>
       {/* <div>{doublevalue}*{bettingamt} </div> */}
            <input placeholder='enter the amount' type='number' className='input col-4' id='amtbox' onChange={e=>{setbetamount(e)}}  min={0}></input>
            <button class="btn col-8 " type="button" onClick={amountadd} disabled={!inputbox>0||showplaybtn||btnname=="ACCEPTED"}>
  <strong>{btnname}<img src={rupee} style={{height:'20%',width:'20%'}}/></strong>
  <div id="container-stars">
    <div id="stars"></div>
  </div>

  <div id="glow">
    <div class="circle"></div>
    <div class="circle"></div>
  </div>
</button>

<h1 className='resulttext' id='resulttext'>WINNING AMOUNT
    <h2 className='texts'>{Number((Number(bettingamt)*Number(gettingx)).toFixed(2))}  <img src={coins} style={{height:'50px'}} /></h2></h1>
<h1 className='resulttext2' id='resulttext2'>BOOM</h1>


        </div>
       </div>

         );
};
export default CrashGame;