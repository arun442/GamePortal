import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route,useLocation} from "react-router-dom";
import React ,{useState,useEffect } from 'react';
import CrashGame from './component/CrashGame';
import Login from './component/Login'
import Listofgames from './component/Listofgames';

function App() {
 

  return (
    <div className="App">
       <div className='main' >
         <Routes>
           <Route exact path="/crashgame" element={<CrashGame />}/>
           <Route exact path="/allgames" element={<Listofgames />}/>
           <Route exact path="/" element={<Login />}/>


         </Routes>
         </div>
         </div>

  );
}

export default App;
